def suma(a,b):
    """
    Suma de dous números.

    A funcion realiza a suma aritmética de dous números, a e b

    :param a: Primeiro sumando
    :param b: Segundo sumando
    :return: resultado da suma a+b
    """

    return a+b
