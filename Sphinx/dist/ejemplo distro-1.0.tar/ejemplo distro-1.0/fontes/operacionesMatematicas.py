def sumar(a, b):
    """
    Calcula la suma de dos números.

    :param a: El primer número.
    :param b: El segundo número.
    :return: El resultado de la suma.
    """
    return a + b