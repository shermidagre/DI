from fontes.operacionesMatematicas import sumar
from ejemplo_distro import sumar2

print(sumar(2,3))
print(sumar2(2,3))
