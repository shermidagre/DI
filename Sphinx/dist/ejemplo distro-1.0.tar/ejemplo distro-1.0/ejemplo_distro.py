
def sumar2(a,b):
    return a+b

